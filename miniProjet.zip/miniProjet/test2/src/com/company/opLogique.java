package com.company;

public class opLogique {
    String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public opLogique(String type) {
        this.type = type;
    }
}
