package com.company;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Stack;

public class Main {


    public static void main(String[] args) {

 try{
     System.out.println("la table de fait contie E et F");
     ArrayList<String> list=new ArrayList<>();
     FileReader file=new FileReader("Donnée.txt");
     BufferedReader br=new BufferedReader(file);
     String line;

     while ((line=br.readLine())!=null) {

        list.add(line);

    }

     System.out.println("list---------------------");
     int Round=1;
     ArrayList<String> Fait=new ArrayList<>();
     Fait.add("E");
     Fait.add("F");

     Stack pile=new Stack();
     String var;
     ArrayList<String> tab=new ArrayList<>();
     tab=list;



     for (int i = 0; i < tab.size(); i++) {
         var = null;
         var = tab.get(i);
         if (Fait.contains(var.substring(2, 3))) {
             System.out.println("regle unitile");
             tab.remove(i);
         } else {
             if (Fait.contains(var.substring(0, 1)) && Fait.contains(var.substring(1, 2))) {

                 Fait.add(var.substring(2, 3));
                  System.out.println("le regles utilisé est R"+i);
                 tab.remove(i);

             } else {
                 if (!pile.contains(i))
                     pile.push(i);
             }

         }
     }

     System.out.println("contenue de la pile"+pile);

     System.out.println("la table de fais"+Fait);




     for (int i = 0; i < tab.size(); i++) {

         var = tab.get((Integer) pile.pop());

         if (Fait.contains(var.substring(2, 3))) {
             System.out.println(" ");


         } else {
             if (Fait.contains(var.substring(0, 1)) && Fait.contains(var.substring(1, 2))) {
                 System.out.println("le regles utilisé est R"+i);
                 Fait.add(var.substring(2, 3));

                 tab.remove(i);

             } else {
                 if (!pile.contains(i))
                     pile.push(i);
             }

         }

         System.out.println("la table de fais"+Fait);
     }

 }
 catch(Exception e){
     System.out.println(e.getMessage());
 }


    }
}
